#include "ServerBase.h"
#include <MyPalletizerBasic.h>
ServerBase::ServerBase()
{
    //todo
}
ServerBase::~ServerBase()
{
    //todo
}
